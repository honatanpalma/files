==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Linux Application Package 1.1.0

   © Copyright IBM Corporation 1996, 2013.  All rights reserved. 

==============================================================================
  本文件不提供任何形式的保證。IBM 不為明示或默示地任何保證（包含但不限於
  本文件內未侵害他人權利、可售性及符合特定效用等保證的資訊）。
  提供本文件，不表示 IBM 對任何專利或版權提供任何授權。


===============================================================================

  此套件是 5733XJ1 IBM i Access Client Solutions 產品的一部分。

  您可以使用 IBM i Access Client Solutions 來連接至任何支援的 IBM i 版本。

  此套件所含的功能，只適用於 Linux 作業系統。
  它是以 7.1 IBM i Access for Linux 產品為基礎，但不含所有特性。
  本套件的 64 位元版本的特性是完整的 64 位元 ODBC 驅動程式，
  可與 unixODBC 驅動程式管理程式套件的 2.2.13 版（以及更新版本）相容。
  如果系統沒有 unixODBC 2.2.13 版或更新的版本，則此套件所含的 ODBC 驅動程式
  將無法正確運作，且可能會造成應用程式損毀。

  若要尋找符合您需求的套件，請解壓縮 .zip 檔並尋找適合您工作站架構的目錄。
  通常是 'x86_64Bit'（用於 64 位元機器）或 'i386_32Bit'（用於32 位元機器）。
  此目錄將包含 .deb 及 .rpm 安裝程式。
  .rpm 檔可用於在 Linux 的 RPM 型發行套件上（如 RedHat、Fedora 或 SuSE）安裝。
  .deb 檔可用於 Debian 型發行套件（如 Ubuntu）。
  
  若要安裝這個套件，您可以使用 Linux 發行套件適用的套件管理程式。
  這包括 zypper、yum、apt-get、rpm 或 dpkg。
  若要執行一般安裝，可使用 dpkg 或 rpm 指令搭配 '-i' 引數。
  範例：
       dpkg -i <filename>.deb
       rpm -i <filename>.rpm

  如需 IBM i Access Client Solutions 的相關資訊，請參閱：
	http://www-03.ibm.com/systems/power/software/i/access/index.html



[文件結束]
