==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Linux Application Package 1.1.0
    
   © Copyright IBM Corporation 1996, 2013.  All rights reserved. 


==============================================================================
  本文档是“按现状”提供的，不附有任何种类的（无论是明示的还是
  暗含的）保证。IBM 免除所有保证，包括但不限于暗含的有关非侵权、
  适销和适用于某种特定用途的保证。提供本文档并不表示 IBM 授予
  用户使用这些专利或版权的任何许可。


===============================================================================

  此程序包是 5733XJ1 IBM i Access Client Solutions 产品的一部分。

  可使用 IBM i Access Client Solutions 来连接至任何受支持的 IBM i 发行版。

  此程序包包含仅在 Linux 操作系统上可用的函数。它基于 7.1 IBM i Access for Linux 产品，
  但没有包含所有功能部件。此程序包的 64 位版本是完整的 64 位 ODBC 驱动程序，与 unixODBC
  驱动程序管理器程序包的 2.2.13（及更新版本）兼容。如果系统没有 unixODBC V2.2.13 或更新
  版本，那么此程序包中包含的 ODBC 驱动程序将无法正常工作，并且可能会导致应用程序崩溃。

  要找到适合您需要的程序包，请解压缩 .zip 文件并找到适合您的工作站体系结构的目录。
  对于 64 位机器，此目录通常是“x86_64Bit”，对于 32 位机器则为“i386_32Bit”。
  此目录将包含 .deb 和 .rpm 安装程序。.rpm 文件可用来安装 Linux 的基于 RPM 的
  分发，例如 RedHat、Fedora 或 SuSE。.deb 文件可在基于 Debian 的分发上使用，
  例如 Ubuntu。
  
  要安装此程序包，可以使用适合 Linux 分发的程序包管理器。这包括 zypper、yum、apt-get、 rpm 或 dpkg。
  使用 dpkg 或 rpm 命令进行的典型安装可通过“-i”自变量进行。
  示例：
       dpkg -i <filename>.deb
       rpm -i <filename>.rpm

  有关 IBM i Access Client Solutions 的更多信息，请参阅：
	http://www-03.ibm.com/systems/power/software/i/access/index.html



[文档结束]
