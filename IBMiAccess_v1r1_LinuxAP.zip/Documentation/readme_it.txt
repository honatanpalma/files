==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Pacchetto di applicazioni Linux 1.1.0

   (c) Copyright IBM Corporation 1996, 2013.  Tutti i diritti riservati. 

==============================================================================
  IBM fornisce la presente pubblicazione "nello stato in cui si trova". Senza garanzie di alcun tipo, né espresse né implicite, ivi incluse,
    a titolo esemplificativo, garanzie implicite di non violazione,
    commerciabilità o idoneità ad uno scopo particolare. Fornendo questo documento, l'IBM non concede licenze per brevetti
    o copyright. 

===============================================================================

  Questo pacchetto fa parte del prodotto 5733XJ1 IBM i Access Client Solutions.

  È possibile utilizzare IBM i Access Client Solutions per connettersi a qualsiasi release di IBM i supportato. 

  Questo pacchetto contiene le funzioni che sono disponibili solo per i sistemi operativi Linux.
  Si basa sul prodotto 7.1 IBM i Access per Linux, ma non contiene tutte le funzioni.

La versione a 64 bit di questo pacchetto contiene un programma di controllo ODBC completo a 64 bit, compatibile
  con la versione 2.2.13 (e successive) dei pacchetti del gestore del programma di controllo unixODBC. Se sul sistema
non è installato unixODBC versione 2.2.13 o una versione successiva, il programma di controllo ODBC contenuto in
questo pacchetto non funzionerà correttamente e potrebbe causare l'interruzione dell'applicazione.

  Per individuare il pacchetto adatto alle proprie esigenze, estrarre il file .zip e trovare l'indirizzario
appropriato per l'architettura della stazione di lavoro in uso. In genere, si tratta di
  'x86_64Bit' per computer a 64 bit o di 'i386_32Bit' per computer a 32 bit. Questo indirizzario
conterrà i programmi di installazione .deb e .rpm. Il file .rpm può essere utilizzato per eseguire l'installazione
sulle distribuzioni di Linux basate su RPM, ad esempio, RedHat, Fedora o SuSE. Il file .deb
può essere utilizzato sulle distribuzioni basate su Debian, ad esempio, Ubuntu. 
  
  Per installare questo pacchetto, è possibile utilizzare il gestore pacchetto adatto per la distribuzione
di Linux. Sono inclusi zypper, yum, apt-get, rpm o dpkg. 
L'installazione tipica con i comandi dpkg o rpm può essere eseguita mediante l'argomento '-i'.
Esempi:
       dpkg -i <filename>.deb
       rpm -i <filename>.rpm

  Per ulteriori informazioni su IBM i Access Client Solutions, accedere all'indirizzo:
	http://www-03.ibm.com/systems/power/software/i/access/index.html



[FINE DEL DOCUMENTO]
