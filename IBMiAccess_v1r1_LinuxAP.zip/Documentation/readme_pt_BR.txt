==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Linux Application Package 1.1.0
    
   (c) Copyright IBM Corporation 1996, 2013.  All rights reserved. 

==============================================================================
  Este documento é fornecido "no estado em que se encontra" sem garantia de nenhum tipo.  A IBM renuncia a todas as garantias, sejam expressas ou implícitas,
    incluindo, mas não limitando, as garantias implícitas de adequação
    a um determinado objeto e a comercialização a respeito das informações
    contidas neste publicação. Fornecendo esta publicação, a IBM não
    garante nenhum direito sobre quaisquer patentes ou copyrights.

===============================================================================

  Este pacote faz parte do produto 5733XJ1 IBM i Access Client Solutions.

  É possível usar o IBM i Access Client Solutions para conectar a qualquer liberação suportada do IBM i.

  Este pacote contém funções que estão disponíveis apenas em sistemas operacionais Linux.  Ele é baseado no produto 7.1 IBM i Access para Linux, mas não contém
  todos os recursos.

  A versão de 64 bits deste pacote contém um driver ODBC de 64 bits completo, compatível
  com a versão 2.2.13 (e mais recente) dos pacotes do gerenciador de drivers unixODBC. Se seu sistema
  não possui o unixODBC versão 2.2.13 ou mais recente, o driver ODBC contido
  neste pacote não funcionará corretamente e pode resultar em travamentos do aplicativo.
  
  Para localizar o pacote apropriado para suas necessidades, extraia o arquivo .zip e localize
  o diretório apropriado para a arquitetura de sua estação de trabalho. Isso geralmente é
  'x86_64Bit' para máquinas de 64 bits ou 'i386_32Bit' para máquinas de 32 bits. Este diretório
  conterá os instaladores .deb e .rpm. O arquivo .rpm pode ser usado para instalação
  em distribuições do Linux baseadas em RPM, tais como RedHat, Fedora ou SuSE. O arquivo .deb
  pode ser usado em distribuições baseadas no Debian, como o Ubuntu. 
  
  Para instalar este pacote, é possível usar o gerenciador de pacotes apropriado para sua distribuição do Linux. Isto inclui o zypper, yum, apt-get, rpm ou dpkg. 
  A instalação típica com comandos dpkg ou rpm pode ser feita com o argumento '-i'.
  Exemplos:
       dpkg -i <filename>.deb
       rpm -i <filename>.rpm

  Para obter informações adicionais sobre o IBM i Access Client Solutions, consulte:
	http://www-03.ibm.com/systems/power/software/i/access/index.html
  
  
    
[FIM DO DOCUMENTO]
