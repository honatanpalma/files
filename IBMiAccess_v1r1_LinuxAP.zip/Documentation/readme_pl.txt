==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Linux Application Package 1.1.0

   (c) Copyright IBM Corporation 1996, 2013.  Wszelkie prawa zastrzeżone. 

==============================================================================
  Dokument ten jest dostarczany w stanie, w jakim się znajduje ("as is"), bez udzielania
  jakichkolwiek gwarancji (rękojmia jest niniejszym również wyłączona.  IBM nie udziela żadnych gwarancji
  wyraźnych czy domniemanych, a w szczególności domniemanych gwarancji przydatności
  handlowej czy też użyteczności dla określonych celów informacji znajdujących
  się w tym dokumencie. Publikując ten dokument, IBM nie udziela
  żadnych licencji w stosunku do patentów ani praw autorskich. 

===============================================================================

  Ten pakiet jest częścią produktu 5733XJ1 IBM i Access Client Solutions.

  Produkt IBM i Access Client Solutions umożliwia nawiązanie połączenia z każdą obsługiwaną wersją platformy IBM i.

  Ten pakiet zawiera funkcje, które są dostępne tylko w systemach operacyjnych Linux. Pakiet jest oparty na produkcie IBM i Access for Linux 7.1, ale nie zawiera jego wszystkich składników. Wersja 64-bitowa tego pakietu obejmuje pełny 64-bitowy sterownik ODBC zgodny z wersją 2.2.13 (i nowszymi) pakietów menedżera sterowników unixODBC. Jeśli system nie zawiera menedżera unixODBC w wersji 2.2.13 lub nowszej, sterownik ODBC zawarty w tym pakiecie nie będzie działać poprawnie i może powodować awarie aplikacji.
  Aby znaleźć pakiet odpowiedni do potrzeb, należy rozpakować plik .zip i znaleźć katalog właściwy dla architektury używanej stacji roboczej. W przypadku komputerów 64- i 32-bitowych są to zwykle odpowiednio katalogi x86_64Bit i i386_32Bit. Te katalogi będą zawierać instalatory plików .deb i .rpm. Plik
.rpm może być używany do instalowania w dystrybucjach systemu Linux opartych na plikach RPM (np. RedHat, Fedora lub SuSE). Plik .deb może być używany w dystrybucjach opartych na dystrybucji Debian (np. Ubuntu). 
  
  Aby zainstalować ten pakiet, można użyć menedżera pakietów odpowiedniego dla używanej dystrybucji systemu Linux. Obejmuje to menedżery zypper, yum, apt-get, rpm lub dpkg. 
  Typową instalację za pomocą komend dpkg lub rpm można przeprowadzić przy użyciu argumentu -i.
  Przykłady:
       dpkg -i <nazwa_pliku>.deb
       rpm -i <nazwa_pliku>.rpm

  Dodatkowe informacje o produkcie IBM i Access Client Solutions są dostępne pod adresem:
	http://www-03.ibm.com/systems/power/software/i/access/index.html



[KONIEC DOKUMENTU]
