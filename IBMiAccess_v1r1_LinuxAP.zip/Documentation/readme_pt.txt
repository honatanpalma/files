==============================================================================

            5733XJ1 Pacote de Aplicações do IBM i Access Client Solutions
              Para Linux  1.1.0

   (c) Copyright IBM Corporation 1996, 2013.  Todos os direitos
reservados. 

==============================================================================
  Este documento é facultado "como está" sem garantia de qualquer tipo. A IBM rejeita quaisquer garantias,
  explícitas ou implícitas, incluindo sem limitação, as
  garantias implícitas de adequação a um determinado
  fim e comercialização no que respeita às informações contidas
  neste documento. Através da disponibilização deste documento, a IBM não
  concede licenças relativas a quaisquer patentes ou direitos de autor. 

===============================================================================

  Este pacote faz parte do produto 5733XJ1 IBM i Access Client Solutions. 

  Poderá utilizar o IBM i Access Client Solutions para estabelecer ligação a qualquer edição suportada do IBM i. 

  Este pacote contém funções que apenas estão disponíveis em sistemas operativos Linux. Baseia-se no produto 7.1 IBM i Access para Linux mas não contém todas as funções. A versão de 64 bits deste pacote contém um controlador de 64 bits de ODBC completo, compatível com a versão 2.2.13 (e mais recente) dos pacotes de gestor de controlador unixODBC. Caso o seu sistema não tenha o unixODBC versão 2.2.13 ou mais recente, o controlador de ODBC contido neste pacote não irá funcionar correctamente e poderá resultar em falhas da aplicação. Para localizar o pacote adequado às suas necessidades, extraia o ficheiro .zip e localize o directório apropriado para a arquitectura da estação de trabalho. Este é geralmente 'x86_64Bit' para máquinas de 64 bits ou 'i386_32Bit' para máquinas de 32 bits. Este directório irá conter instaladores .deb e .rpm. O ficheiro .rpm poderá ser utilizado para instalar em distribuições baseadas em RPM do Linux tais como RedHat, Fedora, ou SuSE. O ficheiro .deb poderá ser utilizado em distribuições baseadas em Debian como Ubuntu. 
  
  Para instalar este pacote, poderá utilizar o gestor de pacotes adequado à sua distribuição do Linux. Isto inclui zypper, yum, apt-get, rpm, ou dpkg. 
  A instalação típica com os comandos dpkg ou rpm poderá ser efectuada com o argumento '-i'. Exemplos:
       dpkg -i <nomeficheiro>.deb
       rpm -i <nomeficheiro>.rpm

  Para obter informações adicionais sobre o IBM i Access Client Solutions, consulte:
	http://www-03.ibm.com/systems/power/software/i/access/index.html




   [FIM DO DOCUMENTO]
