==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Linux Application Package 1.1.0

   (c) Copyright IBM Corporation 1996, 2013.  Alle rechten voorbehouden. 

==============================================================================
  Dit document wordt "AS IS" verstrekt, zonder enige garantie.  Met
  betrekking tot de inhoud van dit document geeft IBM geen enkele
  garantie, uitdrukkelijk noch stilzwijgend, met inbegrip van, maar
  niet beperkt tot, de stilzwijgende garanties voor verkoopbaarheid
  of geschiktheid voor een bepaald doel. Het verstrekken van dit
  document betekent niet dat IBM licentie op enig octrooi of
  auteursrecht verleent. 

===============================================================================

  Dit pakket is onderdeel van het product 5733XJ1 IBM i Access Client
  Solutions.

  U kunt IBM i Access Client Solutions gebruiken voor het maken van een
  verbinding met elke ondersteunde release van IBM i.

  Dit pakket bevat functies die alleen beschikbaar zijn in Linux-besturingssystemen.
  Het is gebaseerd op het product 7.1 IBM i Access for Linux maar bevat niet alle
  voorzieningen ervan.

  De 64 bits-versie van dit pakket bevat een volledig 64-bits ODBC-stuurprogramma,
  dat compatibel is met versie 2.2.13 (en hoger) van de unixODBC-pakketten voor
  stuurprogrammabeheer. Als uw systeem niet beschikt over unixODBC-versie 2.2.13
  of hoger, werkt het ODBC-stuurprogramma van dit pakket niet goed meer,
  en kan het leiden tot het crashen van toepassingen.

  Om het juiste pakket te vinden voor uw situatie, pakt u het ZIP-bestand uit en
  zoekt u de directory die overeenkomt met de architectuur van uw werkstation.
  Dit is doorgaans 'x86_64Bit' voor 64bit computers of 'i386_32Bit' voor
  32bit computers. Deze directory bevat de installatieprogramma's .deb en .rpm. 
  Het .rpm-bestand kunt u gebruiken om te installeren op RPM-distributies
  van Linux, zoals RedHat, Fedora of SuSE. Het .deb-bestand kunt u gebruiken
  voor Debian-distributies zoals Ubuntu. 
  
  Voor het installeren van dit pakket kunt u werken met de package manager
  die geschikt is voor uw Linux-distributie. Dit omvat zypper, yum, apt-get, rpm
  of dpkg. Standaardinstallaties met dpkg- of rpm-opdrachten kunt u uitvoeren
  met het argument '-i'.
  Voorbeelden:
       dpkg -i <bestandsnaam>.deb
       rpm -i <bestandsnaam>.rpm

  Voor aanvullende informatie over IBM i Access Client Solutions raadpleegt u:
	http://www-03.ibm.com/systems/power/software/i/access/index.html



[Einde van document]
