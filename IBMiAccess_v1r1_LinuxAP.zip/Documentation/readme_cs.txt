==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Linux Application Package 1.1.0
    
   (c) Copyright IBM Corporation 1996, 2013. Všechna práva vyhrazena. 

==============================================================================
  Tento dokument je poskytován tak, "jak je", bez jakéhokoli druhu záruky. IBM odmítá veškeré záruky, vyjádřené nebo odvozené, včetně záruk
  poskytnutých bez omezení, zahrnuté záruky způsobilosti
  ke zvláštnímu účelu a prodejnosti s ohledem na informace uvedené
  v tomto dokumentu. Poskytnutím tohoto dokumentu IBM
  neuděluje žádnou licenci k žádným patentům nebo autorským právům. 

===============================================================================

  Tento balík je součástí produktu IBM i Access Client Solutions 5733XJ1.

  Produkt IBM i Access Client Solutions se používá pro připojení k jakémukoli
  podporovanému vydání systému IBM i.

  Tento balík obsahuje funkce, které jsou dostupné pouze na operačních systémech
  Linux. Je založen na produktu IBM i Access for Linux verze 7.1, ale neobsahuje
  všechny funkce. 64bitová verze tohoto balíku obsahuje úplný 64bitový ovladač ODBC, kompatibilní
  s verzí 2.2.13 (a novější) balíků správce ovladačů unixODBC. Pokud váš systém
  nemá unixODBC verze 2.2.13 nebo novější, ovladač ODBC obsažený v tomto balíku
  nebude správně fungovat - výsledkem mohou být havárie aplikace. Chcete-li nalézt balík odpovídající vašim potřebám, rozbalte soubor .zip
  a vyhledejte adresář odpovídající architektuře vaší pracovní stanice. Obvykle
  se jedná o adresáře 'x86_64Bit', v případě 64bitových počítačů, nebo 'i386_32Bit', v případě 32bitových počítačů. Tento adresář
  obsahuje jak instalátory .deb, tak .rpm. Soubor .rpm lze použít k instalaci
  na distribucích operačního systému Linux, založených na systému balíků RPM, jako je např. RedHat, Fedora nebo SuSE. Soubor .deb
  lze použít na distribucích založených na systému Debian, jako např. Ubuntu. 
  
  Chcete-li instalovat tento balík, můžete použít správce balíků vhodného pro vaši distribuci
  operačního systému Linux. To zahrnuje správce zypper, yum, apt-get, rpm nebo dpkg. 
  Typickou instalaci pomocí příkazů dpkg nebo rpm lze provést pomocí argumentu '-i'. Příklady:
       dpkg -i <název_souboru>.deb
       rpm -i <název_souboru>.rpm

  Další informace o produktu IBM i Access Client Solutions naleznete na následujícím webu:
	http://www-03.ibm.com/systems/power/software/i/access/index.html



[KONEC DOKUMENTU]
